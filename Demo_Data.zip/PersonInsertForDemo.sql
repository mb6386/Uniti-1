-- Person Data:

INSERT INTO Person (username, password, firstName, lastName, bio) VALUES
('A', 'A', 'Ann', 'Andrews', 'Ann is awesome'),
('B', 'B', 'Bill', 'Barker', 'Bill is a big shot'),
('C', 'C', 'Cathy', 'Chen', 'Cathy is charismatic'),
('D', 'D', 'Dave', 'Davis', 'Dave is diligent'),
('E', 'E', 'Emily', 'Elhaj', 'Emily is energetic');
